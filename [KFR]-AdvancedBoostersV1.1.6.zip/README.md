
1. Drag the files into your corebot directory
AdvancedBoosters.js -> Addons
2. Backup and Delete your advancedBoosters.yml
3. boot up your bot
Note: If you want the custom emojis they are in the zip file. Youll need to turn them into emojis then send each emoji in chat to get its id. \{emoji}
then paste the emoji data in the config.
Commands:
 -boosting
 -boosting top <page>

