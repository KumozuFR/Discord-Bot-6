Features:

-Customizable Messages
-Advanced config
-Boosting Perks
-Bonus Coins
-Boosting Roles
-Boosting Portal/Profile
-Boosting Notifications
-Advanced Leaderboard
-Advanced Stats Support

Commands:

Boosting - Opens your boosting portal to show your boosting stats and bonus coins.
Boosting - This shows boosting perks and rewards. (If you aren't a booster.)
Boosting Top - This shows the top boosters in your guild.